#!/bin/sh

for i in *.pdf
do
	pdfcrop $i $i
done

mv *.pdf ../.